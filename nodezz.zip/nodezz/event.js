var eve = require('events').EventEmitter;
var ee = new eve;
var timer;
ee.on('start',(num)=>
{
    console.log("timer started");
    timer =setInterval(()=>{
        console.log(num);
        num++;
    },500);
})
ee.on('stop',()=>
{
    console.log("timer stopped");
    clearInterval(timer);
})
ee.emit('start',50);
setTimeout(()=>{
    ee.emit('stop');
},10000);