var buf = Buffer.from("Ranjith");
console.log(buf);

var b = Buffer.alloc(10);
var cn = b.write("This is Sample");
console.log(b);
console.log(b.toString());
console.log(cn);