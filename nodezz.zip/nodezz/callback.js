function sayHello(name,callback)
{
    setTimeout(()=>{
            callback("Hello" + name);
    },5000)
}

console.log("function execution starts");
sayHello("ranjith",function(result)
{
    console.log(result);
})
console.log("execution completed");