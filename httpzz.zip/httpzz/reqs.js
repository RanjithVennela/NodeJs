var fs = require("fs");
var path = require("path");
var layout = getContent("layout.html");
exports.requestHandler = (req,res)=>{
    if(req.url == "/")
    {
        var body = getContent("home.html");
        res.setHeader("content-type","text/html");
        var content = layout.replace("{{body-content}}",body);
        res.write(content);  
        res.end(); 
    }
    else if(req.url=="/login")
    {
        var body = getContent("login.html");
        res.setHeader("content-type","text/html");
        var content = layout.replace("{{body-content}}",body);
        res.write(content);  
        res.end(); 
       
    }
    else if(req.url == "/about")
    {
        var body = getContent("about.html");
        res.setHeader("content-type","text/html");
        var content = layout.replace("{{body-content}}",body);
        res.write(content);    
        res.end(); 
    }
    else if(req.url == "/register" && req.method == "GET")
    {
        var body = getContent("register.html");
        res.setHeader("content-type","text/html");
        var content = layout.replace("{{body-content}}",body);
        res.write(content); 
        res.end();    
    }
    else if(req.url == "/register" && req.method == "POST")
    {
        var formData="";
        req.on("data",(chunk)=>{
            formData=chunk;
        })
        req.on("end",(chunk)=>{
            res.write(formData);
            res.end();
        })
    }
}

function getContent(fileName)
{
    var filePath = path.resolve(__dirname, "views",fileName);
    var content = fs.readFileSync(filePath);
    return content.toString();
}