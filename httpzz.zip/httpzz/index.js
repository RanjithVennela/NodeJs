var http = require("http");
var {requestHandler} = require("./reqs");
var app = require("./server")
var server = http.createServer(app);
server.listen(5000,(err)=>
{
    if(err)
    {
        console.log("couldnot start server");
        return;
    }
    console.log("server started");  
})
