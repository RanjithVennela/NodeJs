const express = require("express")
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const sessionParser = require("express-session");

var app = new express();     // creating express object

app.get("/",(req,res)=>{
    res.header("content-type","text/html").send("<h1> Home Page </h1>");
})

app.get("/login",(req,res)=>{
    res.header("content-type","text/html").send("<h1> Login Page </h1>");
})

app.get("/about",(req,res)=>{
    res.header("content-type","text/html").send("<h1> About Page </h1>");
})

module.exports = app;