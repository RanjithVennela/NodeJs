var fs = require("fs");
var path = require("path")

exports.writeStream = (fileName, content) => {
    var filePath = path.resolve(__dirname, "myFiles", fileName);
    var str = fs.createWriteStream(filePath);
    str.write(content);
    str.close();
}

exports.readStream = (fileName) => {
    var filePath = path.resolve(__dirname, "myFiles", fileName);
    var str = fs.createReadStream(filePath);
    var content=null;
    str.on("data",(chunk)=>
    {
        content +=chunk;
    })
    str.on("end",()=>{
        console.log("stream ended");
        console.log(content);
        str.close();
    })
}