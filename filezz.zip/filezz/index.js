var {writeContent, readContent, writeSyncContent, readSyncContent, readFileContent, writeFileContent} = require("./filezz");

var {readStream, writeStream} = require("./stream");
// writeContent("abc.txt","hello world hello forld");
// readContent("abc.txt",(result)=>
// {
//     console.log(result);
// })


// writeSyncContent("def.txt","ranjith kumar");
// readSyncContent("def.txt");


// writeFileContent("123.txt","This is something good");
// readFileContent("123.txt");


writeStream("111.txt","hello this is streaming");
// readStream("111.txt");