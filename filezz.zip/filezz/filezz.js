var fs = require("fs");
var filezz = require("path");
exports.writeContent = (fileName,content)=>
{
    var filePath = filezz.resolve(__dirname, "myFiles",fileName);
    fs.open(filePath,"w",(err,fd)=>{
        if(err)
        {
            console.log("failed to open file");
            return;
        }
        fs.write(fd,Buffer.from(content),(err,noBytes,buff)=>
        {
            if(err)
            {
                console.log("failed to write");
                return;
            }
            fs.close(fd,(err)=>
            {
                if(err)
                {
                    console.log("failed to closse file")
                }
                console.log("file closed")
            })
        })
    })
}

exports.readContent = (fileName,callback)=>{
    var filePath = filezz.resolve(__dirname,"myFiles",fileName);
    fs.open(filePath,"r",(err,fd)=>
    {
        if(err)
        {
            console.log("failed to open file");
            return;
        }
        var buffer = Buffer.alloc(100,callback);
        fs.read(fd,buffer,0,100,0,(err,noBytes,buff)=>{
            if(err)
            {
                console.log("failed to read file");
                return;
            }
            callback(buff.toString());
            fs.close(fd,(err)=>{
                if(err)
                {
                    console.log("failed to close file")
                }
                console.log("file closed");
            })
               
        })
    })
}

exports.writeSyncContent = (fileName,content)=>
{
    var filePath = filezz.resolve(__dirname, "myFiles",fileName);
    var fd = fs.openSync(filePath,"w");
    if(!fd)
    {
        console.log("failed to open");
    }
    fs.writeSync(fd,Buffer.from(content));
    fs.closeSync(fd);
}

exports.readSyncContent = (fileName)=>{
    var filePath = filezz.resolve(__dirname,"myFiles",fileName);
    var fd = fs.openSync(filePath,"r");
    if(!fd)
    {
        console.log("failed to open file");
    }
    var buff = Buffer.alloc(100);
    fs.readSync(fd,buff,0,100,0);
    console.log(buff.toString());
    fs.closeSync(fd);
}


exports.writeFileContent = (fileName,content)=>{
    var filePath = filezz.resolve(__dirname,"myFiles",fileName);
    fs.writeFile(filePath,content,(err)=>
    {
        if(err)
        {
            console.log("failed to open file");
            return;
        }
    })
}

exports.readFileContent = (fileName)=>
{
    var filePath = filezz.resolve(__dirname,"myFiles",fileName);
    fs.stat(filePath,(err,dada)=>{
        console.log(dada);
    })
    fs.readFile(filePath,(err,data)=>
    {
        if(err)
        {
            console.log("failed to open file");
            return;
        }
        console.log(data.toString());
    })
}